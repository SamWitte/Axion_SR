Computed points of the relativistic self-gravity exchange (16-18 Nov 2026)
==========================================================================
Output of src/ongoing_tests/sg_relativistic/scan_gen.jl (exchange_gen.jl), spin 0.95.  Unzip this archive in the
directory of the scripts of src/scripts/sg_exact (or anywhere, and run them from there): the builders read
prod/res, prod_dip/res, prod2/res (and prodN/res) and energies.pkl relative to their own directory.

  prod/res, prod_dip/res, prod2/res   exact-exchange points (2,488 valid channel points after selection; prod_dip holds
                                      the dipole exchanges repeated with the larger angular basis, Lextra_dip = 10)
  prodN/res                           24,887 points with the Newtonian amplitudes only, Kerr bound states for every level
                                      (scan_gen.jl ... newton_only)
  jobs/                               the job lists (lines: S1 S2 S3 alpha) from which the points were computed
  energies.pkl, energies.txt          Kerr level energies G M omega of the levels (state, alpha), parsed from the worker
                                      logs by energies.py; the builders need them for the absolute normalisation
  frame_check/                        the frame / recoil test of 18 Nov: free = normal calculation,
                                      fixed = SGX_HOLD_FIXED=1 (hole held at rest, reproduces Newton WITHOUT recoil)

One file per channel point, <S1>_<S2>_<S3>_<alpha>.txt, one line per multipole l4 of the fourth quantum:
  S1 S2 S3 alpha spin drho Lextra rmax_fac dest m4 l4  Re,Im a_SI  Re,Im a_N  Re,Im a_NR  Re,Im a_GR  zmax mode_res
  mismatch shift seconds Lextra_dip version
a_SI contact (self-interaction) amplitude, a_N Newtonian with the hole held fixed, a_NR Newtonian + recoil, a_GR
relativistic (NaN in prodN); common normalisation, so ratios are physical:  Gamma_GR / Gamma_NR = sum|a_GR|^2 / sum|a_NR|^2.
Tables are built from these with build_tables2.py --mode gr | kerr_nr | kerr_gr (rates_sg_relativistic_20261117.zip).
