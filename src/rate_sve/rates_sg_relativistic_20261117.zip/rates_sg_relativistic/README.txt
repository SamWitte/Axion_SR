Relativistic self-gravity rate tables (overlay sets), 17 Nov 2026
=================================================================
Three sets of <S1>_<S2>_<S3>_<BH|Inf>_LvrHc_SG.dat tables (columns alpha, Gamma_SI, Gamma_SG, Gamma_x, kappa at f_a = M_pl,
spin 0.95) that REPLACE production tables of the same name when read as an overlay.  Do NOT unzip them into
src/rate_sve: the file names coincide with the production (Newtonian potential + recoil) tables.  Unzip elsewhere and run
    NL_SG_OVERLAY=<directory of one set> NL_SI_FROM_SG=1 julia run_Nlevels.jl --self_grav true ...
(load_rates.jl takes a table from the overlay directory when it exists there, otherwise the production table).

  relativistic_exchange/               graviton exchange from the linearised Einstein equations on Kerr instead of the
                                       Newtonian potential + BH recoil; bound states as in the production tables.
                                       2,321 tables from 2,488 computed channel points.
  relativistic_exchange_kerr_states/   the same, and Kerr bound states for every level (the production tables use
                                       hydrogenic radial functions above n = 8).  10,291 tables, 26,534 points.
  kerr_states_newtonian_exchange/      Kerr bound states only, Newtonian potential + recoil.  10,291 tables.

Coverage: the channels among the levels populated in the evolution runs of the extended self-gravity campaign
(M = 10 and 1e4 Msun, alpha_0 = 0.05 ... 0.25).  Relativistic points: every channel among the levels with peak
occupation above 1e-6, at the run's alpha.  Only the computed nodes are exact; rows at other alphas are the production
row times 1 + c alpha^2 with c from the computed nodes (see build_tables2.py and SUMMARY.tsv in each set, which lists
every computed point with its ratio to the production table).  The black-hole recoil is included: dipole exchanges are
solved in the hole's frame (pinned.jl), and the relativistic amplitude reduces to Newton + recoil as alpha -> 0.
Code: src/ongoing_tests/sg_relativistic (exchange_gen.jl, scan_gen.jl).
